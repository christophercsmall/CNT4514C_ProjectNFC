<?php
        // start the session
        session_start();
        // form token
        $form_token = uniqid();
 
        // create form token session variable and store generated id in it.
        $_SESSION['form_token'] = $form_token;

	$name = $_GET["name"];
	$email = $_GET["email"];
	$score = $_GET["score"];
	$time = $_GET["ttime"];

	$myServer = "CHRIS-PC";
	$connectionInfo = array("UID" => "csmall", "PWD" => "password", "Database" => "LeaderBoardDB");

	$con = sqlsrv_connect($myServer, $connectionInfo);
	if( $con === false ) {
		echo "Unable to connect.";
		die( print_r( sqlsrv_errors(), true));
	}

	  $sql = "INSERT INTO [SCORETABLE] ([NAME], [EMAIL], [TTIME], [SCORE]) VALUES (?, ?, ?, ?);";
	  $params = array($name, $email, $time, $score);
	  $result = sqlsrv_query($con, $sql, $params);
	  
	  sqlsrv_close($conn);  
	  
	  header( 'Location: http://n00931863.sytes.net/congrats.html' );
?> 



