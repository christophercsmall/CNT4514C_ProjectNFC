<?php
	$myServer = "CHRIS-PC";
	$connectionInfo = array("UID" => "csmall", "PWD" => "password", "Database" => "LeaderBoardDB");

	$con = sqlsrv_connect($myServer, $connectionInfo);
	if( $con === false ) {
		echo "Unable to connect.";
		die( print_r( sqlsrv_errors(), true));
	}

	$sql = "SELECT [NAME], [EMAIL], [TTIME], [SCORE] FROM [SCORETABLE];";
	$result = sqlsrv_query($con, $sql);

	
?>

<!DOCTYPE HTML>
<html>

<head>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>

<h1><a href="https://superdevresources.com/responsive-table/" target="_blank">Responsive Table<a/></h1>
<table>
    <thead>
    <tr>
        <th>First Name</th>
        <th>Last Name</th>
		<th>Total Time</th>
        <th>Score</th>
    </tr>
    </thead>
    <tbody>
<?php
	if (sqlsrv_has_rows($result)) {
		while(sqlsrv_fetch($result)) {
			$name = sqlsrv_get_field($result, 0);
			$email = sqlsrv_get_field($result, 1);
			$ttime = sqlsrv_get_field($result, 2);
			$score = sqlsrv_get_field($result, 3);
			
			echo "<tr>";
			echo"<td>$name</td>";
			echo"<td>$email</td>";
			echo"<td>$ttime</td>";
			echo"<td>$score</td>";
			echo"</tr>";
		}
	} 
	
	sqlsrv_close($conn);  

 ?>
	
	<br>    
   
    </tbody>
</table>
</html>
