<?php
	$myServer = "CHRIS-PC";
	$connectionInfo = array("UID" => "csmall", "PWD" => "password", "Database" => "LeaderBoardDB");

	$con = sqlsrv_connect($myServer, $connectionInfo);
	if( $con === false ) {
		echo "Unable to connect.";
		die( print_r( sqlsrv_errors(), true));
	}

	$sql = "SELECT [NAME], [EMAIL], [TTIME], [SCORE] FROM [SCORETABLE] ORDER BY CAST([SCORE] AS INT) DESC, [TTIME] ASC;";
	$result = sqlsrv_query($con, $sql);

	
?>

<!DOCTYPE HTML>
<html>

<head>
	<link rel="stylesheet" type="text/css" href="style.css">	
</head>

<h1 style="text-align:center"><p>Score Table<p/></h1>
<table>
    <thead>
    <tr>
		<th style='text-align:center'>Rank</th>
        <th style='text-align:center'>User Name</th>
        <th style='text-align:center'>E-Mail</th>
		<th style='text-align:center'>Total Time</th>
        <th style='text-align:center'>Score</th>
    </tr>
    </thead>
    <tbody>
<?php	
	$num = 0;
	
	if (sqlsrv_has_rows($result)) {
		while(sqlsrv_fetch($result)) {
			$num++;			
			$name = sqlsrv_get_field($result, 0);
			$email = sqlsrv_get_field($result, 1);
			$ttime = sqlsrv_get_field($result, 2);
			$score = sqlsrv_get_field($result, 3);
			
			echo "<tr>";
			echo "<td style='text-align:center'>$num</td>";
			echo"<td style='text-align:center'>$name</td>";
			echo"<td style='text-align:center'>$email</td>";
			echo"<td style='text-align:center'>$ttime</td>";
			echo"<td style='text-align:center'>$score</td>";
			echo"</tr>";
		}
	} 
	
	sqlsrv_close($conn);  

 ?>
	
	<br>    
   
    </tbody>
</table>
</html>
