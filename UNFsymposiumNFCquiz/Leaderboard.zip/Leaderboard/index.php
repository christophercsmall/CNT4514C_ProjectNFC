<?php
$name = $_GET["name"];
$email = $_GET["email"];
$score = "00/00";
$time = "00:00";

$myServer = "CHRIS-PC";
$connectionInfo = array("UID" => "csmall", "PWD" => "password", "Database" => "LeaderBoardDB");

$con = sqlsrv_connect($myServer, $connectionInfo);
if( $con === false ) {
    echo "Unable to connect.";
    die( print_r( sqlsrv_errors(), true));
}

  $sql = "INSERT INTO [SCORETABLE] ([NAME], [EMAIL], [TTIME], [SCORE]) VALUES (?, ?, ?, ?);";
  $params = array($name, $email, $time, $score);
  $result = sqlsrv_query($con, $sql, $params);
  
  sqlsrv_close($conn);  
?> 

